# Submission Review Prep Guide

This document is a practical script to help you explain the backend clearly to your project manager and in a technical review.

## 1. One-minute summary

This solution is a production-oriented healthcare event backend built with FastAPI, PostgreSQL, Redis, and Celery. It receives typed clinical events, stores raw payloads for audit, processes events asynchronously, applies configurable alert rules, maintains patient state safely under concurrency, and exposes secure reporting APIs with hospital-level data isolation.

Core strengths:
- Reliable ingestion with idempotency.
- Async processing with retry and dead-letter handling.
- Strong data model with migrations, constraints, and indexes.
- Security with JWT + RBAC + audit trail.
- Operational readiness with health checks and metrics.

## 2. Demo flow you can follow live

## Step A: Show architecture and boundaries
- Open the architecture diagram: docs/architecture.md
- Explain separation:
  - API receives and validates.
  - Broker queues work.
  - Worker handles business processing.
  - PostgreSQL stores source-of-truth and reporting data.

## Step B: Show ingestion and idempotency
- Call POST /api/v1/events with a valid VITALS payload.
- Show response: accepted and enqueued.
- Re-send the same event_id.
- Explain expected behavior:
  - Duplicate request is accepted safely.
  - It is not reprocessed.
  - Unique constraint on raw_events.event_id is the safety guard.

## Step C: Show asynchronous processing
- Explain that ingestion does not do full synchronous workflow.
- Show worker process (Celery) running separately.
- Explain API latency stays stable because heavy processing is offloaded.

## Step D: Show alerting and patient state
- Trigger abnormal vitals/lab event.
- Show alert records created.
- Explain one event can create multiple alerts with severity/status.
- Show patient state update fields:
  - latest_event_timestamp
  - latest_clinical_values
  - active_critical_alert_count

## Step E: Show security and isolation
- Login as admin and as scoped hospital user.
- Call timeline/alerts/reports with both users.
- Explain non-admin users are restricted to hospital scope.

## Step F: Show observability and readiness
- Open:
  - /health
  - /health/ready
  - /metrics
- Explain readiness checks database and broker dependencies.

## 3. Failure handling explanation (what to say)

Design goal: never lose auditability, recover transient failures automatically, isolate permanent failures.

How it works:
- Raw events are persisted first for traceability.
- Worker retries transient errors with exponential backoff.
- If failure is permanent or retries are exhausted:
  - Event is moved to failed_events (dead-letter store).
  - Processing history is recorded.
  - Summary counters are updated.

Why this matters:
- Operational teams can inspect failures without losing source payloads.
- System is resilient to temporary outages (DB/broker/network).

## 4. Duplicate prevention explanation (what to say)

Problem: clients retry requests under network uncertainty.

Solution:
- Idempotency key is event_id.
- raw_events.event_id has a unique constraint.
- Duplicate insert attempts are caught and treated as duplicate ingestion.
- Duplicate events are not re-queued, preventing double processing.

Result:
- Safe client retries.
- Exactly-once effect for processing path at application level.

## 5. Database indexes explanation (what to say)

Indexes are designed around query paths and write safety.

Important examples:
- raw_events:
  - unique index on event_id for idempotency.
  - patient_id + occurred_at for timeline queries.
- alerts:
  - patient_id and rule_code indexes.
  - severity + status + triggered_at composite index for alert filtering.
- patient_states:
  - patient_id unique index.
  - hospital + department composite index for scoped views.
- hospital_summary_daily:
  - unique key on summary_date + hospital + department.
  - composite index for grouped report reads.

Why this matters:
- Faster timeline, alerts, and report endpoints.
- Less risk of full-table scans under load.

## 6. Concurrency control explanation (what to say)

Problem: events for the same patient can arrive concurrently and out of order.

Controls used:
- Transaction boundaries in worker processing.
- Row-level locking with SELECT FOR UPDATE on patient_states.
- Timestamp guard:
  - older events do not overwrite newer patient state.

Result:
- Prevents lost updates.
- Protects state consistency under same-patient concurrency.

## 7. Scaling decisions explanation (what to say)

Scaling approach:
- API is stateless: scale horizontally behind a load balancer.
- Worker tier is independent: scale Celery workers based on queue depth.
- Redis decouples ingest spikes from processing throughput.
- Reporting reads pre-aggregated hospital_summary_daily instead of scanning raw transactional tables every request.

Operational levers:
- Increase API replicas for request volume.
- Increase worker concurrency for background throughput.
- Partition workloads by queue if needed.

## 8. Likely PM questions and concise answers

Q: How do we avoid processing the same event twice?
A: event_id unique constraint + duplicate detection in ingestion service, duplicates are not re-queued.

Q: What happens if processing fails?
A: transient failures retry with exponential backoff; permanent/exhausted failures move to failed_events with history and auditability.

Q: How do we protect patient data across hospitals?
A: JWT roles + hospital-scoped authorization filters on timeline, alerts, reports, and acknowledgement operations.

Q: Can this scale for higher traffic?
A: yes, API and worker scale independently, broker buffers load, and summary table reduces reporting cost.

Q: How do we monitor health?
A: health, readiness, and Prometheus metrics endpoints are exposed; readiness checks DB and broker.

## 9. Technical review checklist

Before review:
- Ensure docker compose services are up.
- Run migrations.
- Seed demo users/rules.
- Keep a valid JWT ready for admin and scoped user.

During review:
- Demonstrate duplicate prevention with same event_id.
- Demonstrate one abnormal event producing alerts.
- Demonstrate role-based hospital isolation.
- Demonstrate readiness and metrics endpoints.
- Mention retry/dead-letter behavior and where to inspect failed_events.

After review discussion:
- Call out known limitations and next improvements (rule CRUD expansion, richer integration tests, aggregate freshness tuning).

## 10. Personal speaking template

Use this short format when explaining any subsystem:
- Problem: what risk or need exists.
- Decision: what was implemented.
- Why: why this is safer/faster/clearer.
- Trade-off: what limitation remains.
- Next step: what can be improved.

This structure keeps your explanation clear, confident, and manager-friendly.
