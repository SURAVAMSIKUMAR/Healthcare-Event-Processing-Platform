from celery import Celery

from app.core.config import get_settings

settings = get_settings()

celery_app = Celery(
    "health_events_worker",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.task_serializer = "json"
celery_app.conf.result_serializer = "json"
celery_app.conf.accept_content = ["json"]
celery_app.conf.task_acks_late = True
celery_app.conf.task_default_queue = "health_events"
