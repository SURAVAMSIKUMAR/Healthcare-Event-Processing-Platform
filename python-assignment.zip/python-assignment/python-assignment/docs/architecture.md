# Architecture

```mermaid
flowchart LR
    A[Producers] --> B[FastAPI API]
    B --> C[(PostgreSQL)]
    B --> D[Redis Broker]
    D --> E[Celery Worker]
    E --> C
    B --> F[Prometheus Scrape /metrics]

    subgraph Data
      C1[raw_events]
      C2[processed_events]
      C3[patients/admissions]
      C4[observations/lab_results/medication_orders]
      C5[alerts/alert_rules]
      C6[failed_events]
      C7[processing_history]
      C8[hospital_summary_daily]
      C9[audit_logs/users]
    end

    C --- C1
    C --- C2
    C --- C3
    C --- C4
    C --- C5
    C --- C6
    C --- C7
    C --- C8
    C --- C9
```

## Transaction boundaries
- API ingestion transaction: persist raw event and enqueue task idempotently.
- Worker transaction: normalize event, write domain records, evaluate alerts, update patient state, update summary, and write processing history as one atomic unit.
- Dead-letter transaction: mark raw event failed, insert failed event, update summary, and write processing history atomically.

## Concurrency controls
- Unique constraint on event_id for idempotency.
- Row-level lock on patient_state using SELECT FOR UPDATE during state updates.
- Stale event guard based on latest_event_timestamp prevents out-of-order overwrite.
